"""Audio assembly adapter.

Expected inputs after provider integration:
- main_voice.wav
- whisper.wav (optional)
- ambient_music.wav

Use FFmpeg filters for fades, gain staging, limiting, and format conversion.
Do not bury speech under music; preserve intelligibility and safe playback levels.
"""

from pathlib import Path
import subprocess


def export_mp3(input_wav: Path, output_mp3: Path, bitrate: str = "192k") -> None:
    if not input_wav.exists():
        raise FileNotFoundError(input_wav)
    subprocess.run([
        "ffmpeg", "-y", "-i", str(input_wav), "-codec:a", "libmp3lame",
        "-b:a", bitrate, str(output_mp3)
    ], check=True)
