from datetime import datetime, timezone
from enum import Enum
from uuid import uuid4
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

app = FastAPI(title="SUBLIMINAL CORE AI", version="0.1.0")

class VoiceMode(str, Enum):
    female = "female"
    male = "male"
    dual = "dual"

class ProjectRequest(BaseModel):
    name: str = Field(min_length=2, max_length=100)
    topic: str = Field(min_length=2, max_length=500)
    duration_minutes: int = Field(default=30, ge=1, le=180)
    sentence_count: int = Field(default=100, ge=1, le=500)
    languages: list[str] = ["en", "fa"]
    voice_mode: VoiceMode = VoiceMode.dual
    include_whisper_layer: bool = True
    music_style: str = "cosmic ambient"
    export_formats: list[str] = ["wav", "mp3"]

projects: dict[str, dict] = {}
jobs: dict[str, dict] = {}

@app.get("/health")
def health():
    return {"status": "ok", "service": "SUBLIMINAL CORE AI", "time": datetime.now(timezone.utc).isoformat()}

@app.post("/v1/projects")
def create_project(payload: ProjectRequest):
    project_id = str(uuid4())
    project = {"id": project_id, **payload.model_dump(), "status": "draft", "created_at": datetime.now(timezone.utc).isoformat()}
    projects[project_id] = project
    return project

@app.get("/v1/projects/{project_id}")
def get_project(project_id: str):
    if project_id not in projects:
        raise HTTPException(404, "Project not found")
    return projects[project_id]

@app.post("/v1/projects/{project_id}/generate")
def generate_project(project_id: str):
    if project_id not in projects:
        raise HTTPException(404, "Project not found")
    job_id = str(uuid4())
    project = projects[project_id]
    # Provider integrations are intentionally adapters, not hard-coded credentials.
    brief = {
        "project_id": project_id,
        "topic": project["topic"],
        "duration_minutes": project["duration_minutes"],
        "sentence_count": project["sentence_count"],
        "languages": project["languages"],
        "voice_mode": project["voice_mode"],
        "layers": ["main_voice"] + (["whisper"] if project["include_whisper_layer"] else []) + ["ambient_music"],
        "timeline": [
            {"start": 0, "end": 30, "task": "intro_fade_in"},
            {"start": 30, "end": project["duration_minutes"] * 60 - 30, "task": "main_content_and_ambient"},
            {"start": project["duration_minutes"] * 60 - 30, "end": project["duration_minutes"] * 60, "task": "outro_fade_out"}
        ],
        "exports": project["export_formats"],
        "provider_status": "not_configured"
    }
    jobs[job_id] = {"id": job_id, "project_id": project_id, "status": "queued_for_provider_setup", "brief": brief}
    return jobs[job_id]

@app.get("/v1/jobs/{job_id}")
def get_job(job_id: str):
    if job_id not in jobs:
        raise HTTPException(404, "Job not found")
    return jobs[job_id]
