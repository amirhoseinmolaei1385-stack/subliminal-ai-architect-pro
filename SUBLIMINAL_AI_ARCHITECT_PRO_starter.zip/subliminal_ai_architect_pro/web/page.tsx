export default function Page() {
  return (
    <main style={{minHeight:'100vh',background:'#100b1b',color:'#eee7fa',padding:32,fontFamily:'system-ui'}}>
      <section style={{maxWidth:900,margin:'auto'}}>
        <p style={{letterSpacing:4,color:'#b99ae8'}}>SUBLIMINAL CORE AI</p>
        <h1 style={{fontSize:42,marginBottom:8}}>AI Architect Pro</h1>
        <p style={{color:'#c8badb'}}>Automated subliminal-content production workspace</p>
        <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(210px,1fr))',gap:14,marginTop:32}}>
          {['Content Studio','Voice Layers','Ambient Music','Audio Mastering','Visual Studio','Project Library'].map(x=><article key={x} style={{border:'1px solid #49365f',borderRadius:16,padding:20,background:'#1b1328'}}><h2>{x}</h2><p style={{color:'#bfb2ce'}}>Module ready for backend integration</p></article>)}
        </div>
      </section>
    </main>
  );
}
