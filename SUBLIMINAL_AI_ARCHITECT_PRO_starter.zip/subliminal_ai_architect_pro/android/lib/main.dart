import 'package:flutter/material.dart';

void main() => runApp(const SubliminalArchitectApp());

class SubliminalArchitectApp extends StatelessWidget {
  const SubliminalArchitectApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'Subliminal AI Architect Pro',
    debugShowCheckedModeBanner: false,
    theme: ThemeData.dark().copyWith(
      scaffoldBackgroundColor: const Color(0xFF100B1B),
      colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF9B70D0), brightness: Brightness.dark),
    ),
    home: const Dashboard(),
  );
}

class Dashboard extends StatelessWidget {
  const Dashboard({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('SUBLIMINAL AI ARCHITECT PRO')),
    body: ListView(padding: const EdgeInsets.all(18), children: [
      const Text('SUBLIMINAL CORE AI', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      const Text('FULL AUTO production workspace'),
      const SizedBox(height: 22),
      for (final module in ['New Project','Content Engine','Voice & Whisper','Cosmic Ambient','Audio Mastering','Visual Studio','Project Library'])
        Card(child: ListTile(title: Text(module), trailing: const Icon(Icons.chevron_right))),
    ]),
  );
}
