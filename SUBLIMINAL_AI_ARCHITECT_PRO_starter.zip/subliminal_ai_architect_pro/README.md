# SUBLIMINAL AI ARCHITECT PRO

Multi-platform starter architecture for an automated subliminal-content production platform.

## Included
- FastAPI backend with health, project creation, and generation-job endpoints.
- Worker scaffold for assembling audio with FFmpeg.
- Next.js web dashboard starter page.
- Flutter Android starter screen.
- Docker Compose for API, PostgreSQL, and Redis.

## Important status
This is a runnable **starter scaffold**, not a deployed production service and not a compiled APK. AI/TTS/music providers require credentials and must be configured by the operator. The generation endpoint currently creates a structured production brief; connect a chosen provider to generate real audio.

## Run backend locally
```bash
cd backend
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```
Open http://127.0.0.1:8000/docs

## Run infrastructure
```bash
docker compose up -d postgres redis
```

## Web and Android
- `web/` contains a Next.js starter page. Create/install a Next.js app and copy `page.tsx` into `app/page.tsx`.
- `android/` contains the Flutter screen. Create a Flutter project (`flutter create .`) and replace `lib/main.dart`.

## Production checklist
1. Add authentication, roles, rate limits, audit logs, and secret management.
2. Configure a TTS provider and verify its commercial-use/licensing terms.
3. Configure licensed music or original ambient generation.
4. Implement background job persistence and object storage.
5. Add audio loudness/peak checks and export tests.
6. Add privacy, consent, retention, and deletion controls.
7. Build/sign the Android APK and deploy the web/API services.

## Safety and claims
The product generates affirmations and relaxation audio. Do not market subliminal content as a proven treatment or promise guaranteed personality, health, or behavioral changes. Keep speech intelligible, avoid unsafe volume levels, and disclose all audio layers.
